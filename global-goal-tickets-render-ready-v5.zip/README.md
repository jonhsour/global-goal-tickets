# Global Goal Tickets — Render Ready v5

This is a single Node.js web service: customer marketplace + admin panel.

## Deploy on Render
- Runtime: Node
- Build Command: `npm install`
- Start Command: `npm start`
- Health Check Path: `/health`

Render can deploy a Node web service from a connected GitHub repository. The service must bind to the `PORT` environment variable and `0.0.0.0`; this project does both.

## Admin login
Set these environment variables in Render:
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`

If you do not set them, the demo defaults are used. Change them before public launch.

## Important data note
This starter stores data in `data.json`. Render's default filesystem is ephemeral, so data can disappear after a restart or redeploy unless you attach persistent storage or move the data to a managed database. For a real ticket business, use a managed database such as Postgres.

## Legal/operational note
This is a ticket marketplace software starter. Do not claim FIFA affiliation or official reseller status unless you are formally authorized. Only list inventory you are legally authorized to sell and comply with applicable ticketing, consumer-protection, and payment rules.
