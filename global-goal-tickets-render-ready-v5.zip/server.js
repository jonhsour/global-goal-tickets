const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 10000;
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@globalgoaltickets.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'ChangeThisImmediately123!';
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data.json');

const seed = {
  tickets: [
    { id: 't1', match: 'Opening Match', venue: 'Mexico City Stadium', date: '2026-06-11', category: 'Category 1', price: 250, quantity: 20 },
    { id: 't2', match: 'England vs Croatia', venue: 'London Stadium', date: '2026-06-17', category: 'Category 2', price: 180, quantity: 15 },
    { id: 't3', match: 'Final', venue: 'New York / New Jersey Stadium', date: '2026-07-19', category: 'Category 1', price: 900, quantity: 8 }
  ],
  orders: []
};

function load() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch {
    save(seed);
    return JSON.parse(JSON.stringify(seed));
  }
}
function save(db) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}
let db = load();

function send(res, status, body, type='application/json') {
  res.writeHead(status, {'Content-Type': type, 'Access-Control-Allow-Origin': '*'});
  res.end(type === 'application/json' ? JSON.stringify(body) : body);
}
function parseBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', c => raw += c);
    req.on('end', () => {
      try { resolve(raw ? JSON.parse(raw) : {}); } catch { reject(new Error('Invalid JSON')); }
    });
  });
}
function id(prefix) { return prefix + crypto.randomBytes(5).toString('hex'); }
function html() {
  return fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf8');
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const method = req.method;

  if (method === 'GET' && url.pathname === '/health') return send(res, 200, {ok:true});
  if (method === 'GET' && url.pathname === '/') return send(res, 200, html(), 'text/html; charset=utf-8');

  if (method === 'GET' && url.pathname === '/api/tickets') {
    const q = (url.searchParams.get('q') || '').toLowerCase();
    const tickets = db.tickets.filter(t => !q || `${t.match} ${t.venue} ${t.category}`.toLowerCase().includes(q));
    return send(res, 200, tickets);
  }

  if (method === 'POST' && url.pathname === '/api/orders') {
    try {
      const body = await parseBody(req);
      const ticket = db.tickets.find(t => t.id === body.ticketId);
      const qty = Number(body.quantity);
      if (!ticket) return send(res, 404, {error:'Ticket not found'});
      if (!body.name || !body.email || !Number.isInteger(qty) || qty < 1) return send(res, 400, {error:'Name, email and a valid quantity are required'});
      if (qty > ticket.quantity) return send(res, 400, {error:'Not enough tickets available'});
      ticket.quantity -= qty;
      const order = {
        id: 'GGT-' + crypto.randomBytes(4).toString('hex').toUpperCase(),
        ticketId: ticket.id,
        match: ticket.match,
        name: body.name,
        email: body.email,
        country: body.country || '',
        quantity: qty,
        total: qty * ticket.price,
        status: 'Pending',
        createdAt: new Date().toISOString()
      };
      db.orders.unshift(order);
      save(db);
      return send(res, 201, order);
    } catch (e) { return send(res, 400, {error:e.message}); }
  }

  if (method === 'POST' && url.pathname === '/api/admin/login') {
    try {
      const body = await parseBody(req);
      if (body.email === ADMIN_EMAIL && body.password === ADMIN_PASSWORD) {
        return send(res, 200, {ok:true, token: crypto.randomBytes(16).toString('hex')});
      }
      return send(res, 401, {error:'Invalid admin credentials'});
    } catch (e) { return send(res, 400, {error:e.message}); }
  }

  if (url.pathname.startsWith('/api/admin/')) {
    const auth = req.headers.authorization || '';
    if (!auth.startsWith('Bearer ')) return send(res, 401, {error:'Admin login required'});
  }

  if (method === 'GET' && url.pathname === '/api/admin/dashboard') {
    return send(res, 200, {
      tickets: db.tickets.length,
      available: db.tickets.reduce((a,t)=>a+t.quantity,0),
      orders: db.orders.length,
      pending: db.orders.filter(o=>o.status==='Pending').length
    });
  }

  if (method === 'GET' && url.pathname === '/api/admin/orders') return send(res, 200, db.orders);
  if (method === 'GET' && url.pathname === '/api/admin/tickets') return send(res, 200, db.tickets);

  if (method === 'POST' && url.pathname === '/api/admin/tickets') {
    try {
      const body = await parseBody(req);
      const ticket = {
        id: id('t'),
        match: String(body.match || ''),
        venue: String(body.venue || ''),
        date: String(body.date || ''),
        category: String(body.category || 'Category 1'),
        price: Number(body.price || 0),
        quantity: Number(body.quantity || 0)
      };
      if (!ticket.match || !ticket.venue || ticket.price < 0 || ticket.quantity < 0) return send(res, 400, {error:'Complete the ticket details'});
      db.tickets.push(ticket); save(db); return send(res, 201, ticket);
    } catch (e) { return send(res, 400, {error:e.message}); }
  }

  if (method === 'PATCH' && url.pathname.startsWith('/api/admin/orders/')) {
    try {
      const order = db.orders.find(o => o.id === url.pathname.split('/').pop());
      if (!order) return send(res, 404, {error:'Order not found'});
      const body = await parseBody(req);
      order.status = body.status || order.status;
      save(db); return send(res, 200, order);
    } catch (e) { return send(res, 400, {error:e.message}); }
  }

  if (method === 'DELETE' && url.pathname.startsWith('/api/admin/tickets/')) {
    const ticketId = url.pathname.split('/').pop();
    db.tickets = db.tickets.filter(t => t.id !== ticketId);
    save(db); return send(res, 200, {ok:true});
  }

  return send(res, 404, {error:'Not found'});
});

server.listen(PORT, '0.0.0.0', () => console.log(`Global Goal Tickets running on port ${PORT}`));
