import "dotenv/config";
import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database(path.join(__dirname, "../global-goal-tickets.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS tickets (
  id TEXT PRIMARY KEY,
  match TEXT NOT NULL,
  date TEXT NOT NULL,
  venue TEXT NOT NULL,
  category TEXT NOT NULL,
  section TEXT NOT NULL,
  price REAL NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  available INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Available',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  country TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  customer_id INTEGER,
  ticket_id TEXT,
  qty INTEGER NOT NULL,
  total REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'Pending',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(customer_id) REFERENCES customers(id),
  FOREIGN KEY(ticket_id) REFERENCES tickets(id)
);
`);

const adminEmail = process.env.ADMIN_EMAIL || "admin@globalgoaltickets.com";
const adminPassword = process.env.ADMIN_PASSWORD || "ChangeThisImmediately123!";
const existing = db.prepare("SELECT id FROM admins WHERE email = ?").get(adminEmail);
if (!existing) {
  db.prepare("INSERT INTO admins (email, password_hash) VALUES (?, ?)").run(
    adminEmail, bcrypt.hashSync(adminPassword, 12)
  );
}
if (db.prepare("SELECT COUNT(*) count FROM tickets").get().count === 0) {
  const seed = db.prepare(`INSERT INTO tickets (id,match,date,venue,category,section,price,currency,available,status) VALUES (?,?,?,?,?,?,?,?,?,?)`);
  seed.run("T-1001","Spain vs Argentina","19 Jul 2026","New York / New Jersey","Final","Category 1",7380,"USD",8,"Available");
  seed.run("T-1002","France vs England","18 Jul 2026","Miami","3rd Place","Category 2",1450,"USD",12,"Available");
}

const app = express();
app.use(cors());
app.use(express.json());

const auth = (req,res,next) => {
  const token = req.headers.authorization?.replace("Bearer ","");
  if (!token) return res.status(401).json({error:"Authentication required"});
  try { req.admin = jwt.verify(token, process.env.JWT_SECRET || "dev-secret-change-me"); next(); }
  catch { return res.status(401).json({error:"Invalid or expired session"}); }
};

app.post("/api/auth/login", (req,res) => {
  const {email,password} = req.body;
  const admin = db.prepare("SELECT * FROM admins WHERE email = ?").get(email);
  if (!admin || !bcrypt.compareSync(password || "", admin.password_hash))
    return res.status(401).json({error:"Invalid credentials"});
  const token = jwt.sign({id:admin.id,email:admin.email}, process.env.JWT_SECRET || "dev-secret-change-me", {expiresIn:"8h"});
  res.json({token, admin:{email:admin.email}});
});

app.get("/api/dashboard", auth, (req,res) => {
  const revenue = db.prepare("SELECT COALESCE(SUM(total),0) revenue FROM orders WHERE status != 'Cancelled'").get().revenue;
  const activeTickets = db.prepare("SELECT COUNT(*) count FROM tickets WHERE status = 'Available'").get().count;
  const orders = db.prepare("SELECT COUNT(*) count FROM orders").get().count;
  const pending = db.prepare("SELECT COUNT(*) count FROM orders WHERE status = 'Pending'").get().count;
  res.json({revenue, activeTickets, orders, pending});
});

app.get("/api/tickets", auth, (req,res) => res.json(db.prepare("SELECT * FROM tickets ORDER BY created_at DESC").all()));
app.post("/api/tickets", auth, (req,res) => {
  const {match,date,venue,category,section,price,currency="USD",available,status="Available"} = req.body;
  if (!match || !price || available === undefined) return res.status(400).json({error:"Match, price and available quantity are required"});
  const id = "T-" + Math.floor(1000 + Math.random()*8999);
  db.prepare(`INSERT INTO tickets (id,match,date,venue,category,section,price,currency,available,status) VALUES (?,?,?,?,?,?,?,?,?,?)`)
    .run(id,match,date,venue,category,section,Number(price),currency,Number(available),status);
  res.status(201).json(db.prepare("SELECT * FROM tickets WHERE id=?").get(id));
});
app.put("/api/tickets/:id", auth, (req,res) => {
  const {match,date,venue,category,section,price,currency,available,status} = req.body;
  db.prepare(`UPDATE tickets SET match=?,date=?,venue=?,category=?,section=?,price=?,currency=?,available=?,status=? WHERE id=?`)
    .run(match,date,venue,category,section,Number(price),currency,Number(available),status,req.params.id);
  res.json(db.prepare("SELECT * FROM tickets WHERE id=?").get(req.params.id));
});
app.delete("/api/tickets/:id", auth, (req,res) => {
  db.prepare("DELETE FROM tickets WHERE id=?").run(req.params.id);
  res.json({ok:true});
});

app.get("/api/orders", auth, (req,res) => res.json(db.prepare(`
SELECT o.id,o.qty,o.total,o.status,o.created_at,
       c.name customer,c.email,country,
       t.match ticket
FROM orders o
LEFT JOIN customers c ON c.id=o.customer_id
LEFT JOIN tickets t ON t.id=o.ticket_id
ORDER BY o.created_at DESC`).all()));
app.patch("/api/orders/:id/status", auth, (req,res) => {
  const {status} = req.body;
  if (!["Pending","Confirmed","Completed","Cancelled"].includes(status)) return res.status(400).json({error:"Invalid status"});
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(status,req.params.id);
  res.json({ok:true});
});

app.get("/api/customers", auth, (req,res) => res.json(db.prepare(`
SELECT c.id,c.name,c.email,c.country,c.created_at joined,COUNT(o.id) orders
FROM customers c LEFT JOIN orders o ON o.customer_id=c.id
GROUP BY c.id ORDER BY c.created_at DESC`).all()));


// Public marketplace / customer APIs
app.get("/api/public/tickets", (req,res) => {
  res.json(db.prepare("SELECT id,match,date,venue,category,section,price,currency,available,status FROM tickets WHERE status='Available' AND available>0 ORDER BY date ASC").all());
});

app.post("/api/public/orders", (req,res) => {
  const {name,email,country,ticketId,qty} = req.body;
  const quantity = Number(qty);
  if (!name || !email || !ticketId || !Number.isInteger(quantity) || quantity < 1)
    return res.status(400).json({error:"Name, email, ticket and valid quantity are required"});
  const ticket = db.prepare("SELECT * FROM tickets WHERE id=? AND status='Available'").get(ticketId);
  if (!ticket || ticket.available < quantity) return res.status(400).json({error:"Ticket availability has changed"});
  const total = Number(ticket.price) * quantity;
  const orderId = "GG-" + Math.floor(100000 + Math.random()*899999);
  const create = db.transaction(() => {
    let customer = db.prepare("SELECT * FROM customers WHERE email=?").get(email);
    if (!customer) {
      const info = db.prepare("INSERT INTO customers (name,email,country) VALUES (?,?,?)").run(name,email,country||null);
      customer = {id: info.lastInsertRowid};
    } else {
      db.prepare("UPDATE customers SET name=?,country=? WHERE id=?").run(name,country||null,customer.id);
    }
    db.prepare("INSERT INTO orders (id,customer_id,ticket_id,qty,total,status) VALUES (?,?,?,?,?,'Pending')")
      .run(orderId,customer.id,ticketId,quantity,total);
    db.prepare("UPDATE tickets SET available=available-? WHERE id=?").run(quantity,ticketId);
  });
  create();
  res.status(201).json({orderId,total,status:"Pending"});
});

app.get("/api/public/orders/:id", (req,res) => {
  const order = db.prepare(`
    SELECT o.id,o.qty,o.total,o.status,o.created_at,
           c.name,c.email,c.country,
           t.match,t.date,t.venue,t.category,t.section
    FROM orders o
    LEFT JOIN customers c ON c.id=o.customer_id
    LEFT JOIN tickets t ON t.id=o.ticket_id
    WHERE o.id=?`).get(req.params.id);
  if (!order) return res.status(404).json({error:"Order not found"});
  res.json(order);
});

app.get("/api/health", (req,res) => res.json({ok:true,service:"Global Goal Tickets API"}));

app.listen(process.env.PORT || 4000, () => console.log(`API running on http://localhost:${process.env.PORT || 4000}`));
