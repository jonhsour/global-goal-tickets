# Global Goal Tickets — Version 4

This is the backend-connected version of the admin panel.

## What changed
- Real Express API
- SQLite database
- Password hashing with bcrypt
- JWT admin authentication
- Server-side ticket CRUD
- Server-side order status management
- Server-side customer directory
- Dashboard metrics from database
- CORS/API configuration
- Admin session token

## Run
1. Install Node.js
2. Open this folder in a terminal
3. Run `npm install`
4. Run `npm run install-all`
5. Copy `server/.env.example` to `server/.env`
6. Change `JWT_SECRET` and `ADMIN_PASSWORD` immediately
7. Run `npm run dev`
8. Open the Vite URL shown by the client

## Default demo login
Email: admin@globalgoaltickets.com
Password: ChangeThisImmediately123!

## Important
This is a production-oriented foundation, but it is not a deployed cloud service. Before public launch, deploy the API and database, use a managed database, enable HTTPS, rotate secrets, add rate limiting and audit logs, and connect only to a verified/authorized ticket inventory and compliant payment workflow. Do not claim FIFA affiliation or official reseller status unless formally authorized.


## Version 4 additions
- Customer-facing ticket marketplace
- Searchable public ticket listings
- Customer order submission
- Automatic ticket availability reduction when an order is submitted
- Customer order ID generation
- Customer order confirmation screen
- Public order lookup API
- Admin panel remains connected to the same backend/database

The current order flow submits an order for admin confirmation. Payment integration is not included in this build.
